//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/5/18 
//Task no: Week13#Assignment4#1
/*Requirements: Write a program to read students' names and scores from a file student.txt, and store the 
students' information in a linked list where the elements are stored in descending order. The program then 
will print out the students�� information in the linked list from the head to the end. For example, if the 
information in the file is as follows (Note: there is no limit to the number of students):
Jack 10
Ray 100
David 12 */
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct node{
	char name[20];
	int score;
	struct node *next;
};

int main(){
	int n;
	printf("Please enter the number of student you want to enter:");
	scanf("%d", &n);  // The length of the linklist
	int i = 1;
	FILE *fp;
	fp = fopen("student.txt", "r");
	struct node *pnode1, *pnode2, *head;  // Create a list
	pnode1 =(struct node*)malloc(sizeof(struct node));
	fscanf(fp, "%s %d", pnode1 -> name, &pnode1 -> score);
	head = pnode1;  // Create links between nodes
	while (i < n){
		pnode2 = (struct node*)malloc(sizeof(struct node));
		fscanf(fp, "%s %d", pnode2 -> name, &pnode2 ->score);
		pnode1 -> next = pnode2;
		pnode1 = pnode2;  // Create links between nodes
		i++;
	}
	pnode2 -> next = NULL;
	fclose(fp);

	printf("After sort by descending order of score, the students' information are:\n");
	int t; char s[20];
	struct node *head1;
	head1 = head;
	node *last = NULL;
	if(head1 == NULL || head1 -> next == NULL)
		return 0;
	while(head1 != last){  // The condition to end the bubble sort loop
		while(head1 -> next != last){
			if(head1 -> score < head1 -> next -> score){
				t = head1 -> score;
				head1 -> score = head1 -> next -> score;
				head1 -> next -> score = t;
				strcpy(s, head1 -> name);
				strcpy(head1 -> name, head1 -> next -> name);
				strcpy(head1 -> next -> name, s);
			}
			head1 = head1 -> next;  // start the new loop with the  head1 -> next
		}
		last = head1;
		head1 = head;  
	} 
	if(head == NULL) 
		return 0; 
	else{
		while (head){
			printf("%s\t%d\n", head -> name, head -> score);
			head = head -> next;  // print the node in the linklist  
		}
	}
	return 0;
}
 
/*
	for(; head1 -> next -> next!= NULL; head1 = head1 -> next){
		for(next2 = head1 -> next; next2 -> next != NULL; next2 -> next)
			if(head1 -> score < next2 -> score){
				t = head1 -> score;
				head1 -> score = next2 -> score;
				next2 -> score = t;
				strcpy(s, head1 -> name);
				strcpy(head1 -> name, next2 -> name);
				strcpy(next2 -> name, s);
			}
	}
*/ 

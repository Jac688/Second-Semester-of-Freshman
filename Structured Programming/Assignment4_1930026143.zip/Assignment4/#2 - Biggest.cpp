//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/5/18 
//Task no: Week13#Assignment4#1
/*Requirements: Write a program which includes two functions. The main function reads the 
sequence of integers (assume ends with -1), a sub-function will find the biggest integer 
and lowest integer. The main function will call the sub-function, pass the integers to it 
through parameters, and print the biggest integer and lowest integer.  */
#include<stdio.h>
#include<stdlib.h>

void biggest(int a[], int i, int *max, int *min){
	int x;

	for(x = 1; x < i; x++){
		if(*max < a[x]){  // If there is a number bigger than previous one, it wil replace the one
			*max = a[x];  
		}
	}
	int y;
	for(y = 1; y < i; y++){
		if(*min > a[y]){  // If there is a number bigger than previous one, it wil replace the one
			*min = a[y];
		}
	}
	return;
}

int main(){
	int *a;
	int min = 0, max = 0;
	int n = 20, i = 10;
	printf("Please enter a sequence of integers and end with -1: ");
	a = (int *)malloc(n*sizeof(int));  // Create a dynamic memory that can be expanded at any time 
	while(1){
		scanf("%d", a + i);
		if(a[i] == -1)
			break;
		i++;
		if(i == n){  // When the input array reaches a certain size, the dynamic memory is automatically increased 
			n += 20;
			a = (int*)realloc(a, n*sizeof(int));
			if(a == NULL)
				return 0;
		}
	}
	max = *a; // Begin from the a[0]		
	min = *a;  // As the max, it finds the min to begin from the a[0]
	biggest(a, i, &max, &min);    // Function call, passed the max and min
    printf("The biggeest integers in the sequence is: %d\n", max);  
    printf("The lowest integers in the sequence is: %d", min); 
	free(a);  // Free the memory 
    return 0;
}


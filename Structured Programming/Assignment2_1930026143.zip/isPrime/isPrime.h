#include<stdio.h>
int isPrime(int n);  //  Sub-function intisPrime(int n) - function prototypes
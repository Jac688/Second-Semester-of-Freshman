//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/2/19
//Task no: Week1#Task1#
//Requirements:different return for programs P1 and P2
#include<stdio.h>
int main()
{
printf("Hello\n");
printf("World\n");
return 0;
}
//P1 output Hello and P2 output Hello World//
//P1 return value 1 and P2 return value 0//
//Return statement is used for ending the function// 

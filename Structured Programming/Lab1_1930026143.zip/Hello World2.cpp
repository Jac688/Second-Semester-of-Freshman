//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/2/18
//Task no: Week1#Task0#
//Requirements: print "Hello World"
/* Anthor example*/
#include<stdio.h>
int main()
{
  printf("Hello World\nHello World\nHello World\n");
  return 0;
}

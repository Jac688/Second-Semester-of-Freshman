//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/3/30 
//Task no: Week7#Lecture10#
//Requirements: Judge the following initialization are correct.
/*
�Cchar str[10] = {'y', 'e', 's'};
  It is incorrect because there is lack of '\0' in {}.
  
�Cchar str[10] = "Good Morning";
  It is incorrect because str[10] have not enough room to store the string "Good Morning"
  
�Cchar str = "Hi";
  It is incorrect because there is lack of [] after the str, so it is not defined as a string.
  
�Cchar str[] = 'Good';
  It is incorrect because it should use "" if it is a string.
  
- char str[] = "O";
  It is incorrect because there is only one character, so "O" is not a string.
*/

  


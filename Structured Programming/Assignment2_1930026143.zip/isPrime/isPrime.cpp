//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/4/19
//Task no: Week9#Assignment2#3
/*Requirements:  Write a program to find and print out all the prime numbers between 5 and 100(inclusive). 
It is required that the program should include two functions: a main function and a sub-function intisPrime(int n). 
If n is a prime number, the function isPrime will return 1 otherwise return 0. It is required that two functions 
are put in two .cpp files (one for main function, one for isPrime). Createone .hpp file to put the prototype of sub-function. */ 
#include"isPrime.h"
int isPrime(int n){
	int i;
	int x = 0;
	for(i = 2; i < n; i++){  // Determine whether it is a prime
		if(n%i == 0)
			x++;
	}
	// If n is a prime number, the function isPrime will return 1 otherwise return 0
	if(x == 0)  // n is not a prime number 
		return 0;
	else  //n is a prime number
		return 1;
}
//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/3/23
//Task no: Week6#Lecture9#
//Requirements: Answer four following question.

/* 
  float averageGrade(int grade1, int grade2);
	
  1.Function name?
	The Function name is 'averageGrade'.
	  
  2.How many input variables?
	There are two input variables.
	  
  3.What are the types of input variables?
	The types of input variables are int(integer). 
	  
  4.What is the type of the return value (output value)?
    The type of the return value (output value) is float.
	  
*/

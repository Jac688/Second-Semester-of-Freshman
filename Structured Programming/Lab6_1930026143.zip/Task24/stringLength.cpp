//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/3/24
//Task no: Week5#Task24#
//Requirements: Write a program that includes two functions: main and stringLength.
#include"stringLength.h"

int stringLength(char s[]){
	return strlen(s);
}
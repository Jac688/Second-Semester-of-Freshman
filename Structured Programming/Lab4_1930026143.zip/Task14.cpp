//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/3/10
//Task no: Week4#Task14#
/*Requirements:Write a program to calculate and output the 
sum of the even numbers from 1 to 100 (inclusive) and the 
sum of odd numbers from 1 to 100 (inclusive).  */
#include<stdio.h>
int main()
{
	int i;
	int sum = 0;
	
	for(i = 1; i <= 100; i++)
	{
		if (i % 2 == 0)
		continue; 
		sum = sum + i; 
	}
	printf("sum = %d", sum);
	return 0;
}	

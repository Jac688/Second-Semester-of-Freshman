//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/3/23
//Task no: Week6#Lecture9#
//Requirements: Answer four following question.

/*
  void printASCIICode(char code);
  
  1.Function name?
    the function name is 'printASCIICode'.
    
  2.How many input variables?
    There is one input variable.
    
  3.What are the types of input variables?
    The types of input variable is char.
    
  4.What is the type of the return value (output value)? 
    The type of the return value (output value) is void.
    
*/

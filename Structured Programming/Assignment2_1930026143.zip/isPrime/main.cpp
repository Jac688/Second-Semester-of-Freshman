#include"isPrime.h"
int main(){
	int i;
	for(i = 5; i <= 100; i++){ // Select number between 5 and 100
		if(isPrime(i) == 1)  // Function call
			printf("%d ", i);
	}
	return 0;
}
//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/3/10
//Task no: Week4#Task16#
/*Requirement: Write a program using nested for statement 
to print out the following pattern:
*********
=======
*****
===
*               */
#include<stdio.h>
int main()
{
	int n = 8;
	int c, r;
	for(r = 0; r <= 8; r += 2)
	{
		for(c = 8; c >= r; c--)
		{   
			if(r/2 % 2 == 1) // Distinguish the two situation = and * // 
			printf("=");
			else if(r/2 % 2 == 0)
			printf("*");
		}
		printf("\n");
	}
	return 0;
}

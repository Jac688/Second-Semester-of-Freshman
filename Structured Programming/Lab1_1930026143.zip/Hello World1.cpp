//Progframmer: Jack
//Student ID: 1930026143
//Date: 2020/2/18
//Task no: Week1#Task0#
//Requirements: print "Hello World"
/* just an example */
#include<stdio.h>
int main()
{
  printf("Hello World\n"); // 1st
  printf("Hello World\n"); // 2nd
  printf("Hello World\n"); // 3rd
  return 0;
}

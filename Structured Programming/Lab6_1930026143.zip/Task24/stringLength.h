#include<stdio.h>
#include<string.h>
int stringLength(char s[]);